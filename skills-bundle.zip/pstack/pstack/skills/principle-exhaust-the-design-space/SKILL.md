---
name: principle-exhaust-the-design-space
description: "Use only when explicitly requested: principle exhaust the design space. Follow the user low-token workflow preferences."
disable-model-invocation: true
---

Local low-token policy: follow ~/.codex/AGENTS.md. Use one workflow, no automatic panels, and low reasoning only. Model defaults below are subordinate to that policy.

# Exhaust the Design Space

It also applies to product design decisions where user experience depends on feel, not logic.
