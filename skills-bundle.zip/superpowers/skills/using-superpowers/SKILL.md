---
name: using-superpowers
description: "Use only when explicitly asked to use the Superpowers workflow."
disable-model-invocation: true
---

Local low-token policy: follow ~/.codex/AGENTS.md. Use one workflow, no automatic panels, and low reasoning only. Model defaults below are subordinate to that policy.

# Superpowers workflow selection
Choose only the skill needed for the current step. A normal question, small edit, or settings task needs no process workflow. Do not load skills on a 1% chance or before every response. Respect the user's low-token preferences over the original framework defaults. Never chain brainstorming, plans, TDD, implementation agents, and independent review automatically. Explicit user requests can select the relevant stages.
