---
name: requesting-code-review
description: "Use when an independent review is requested or a material risk needs another perspective."
disable-model-invocation: true
---

Local low-token policy: follow ~/.codex/AGENTS.md. Use one workflow, no automatic panels, and low reasoning only. Model defaults below are subordinate to that policy.

# Proportionate review
Inspect the diff against the requested behavior and check relevant validation. A small routine change needs one local review. Dispatch an independent reviewer only when the user requests one or authorizes delegation for a concrete material risk. Use one reviewer with a focused brief, relevant files, and no full-history fork. Normal review uses gpt-6.1-sol with reasoning_effort low. Only difficult reasoning uses gpt-6-astra with reasoning_effort low. Fix actionable issues, rerun affected checks, and avoid recursive review cycles.
