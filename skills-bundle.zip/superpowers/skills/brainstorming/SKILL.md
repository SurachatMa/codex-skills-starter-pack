---
name: brainstorming
description: "Use when the user asks to brainstorm or a substantial design choice is unresolved."
disable-model-invocation: true
---

Local low-token policy: follow ~/.codex/AGENTS.md. Use one workflow, no automatic panels, and low reasoning only. Model defaults below are subordinate to that policy.

# Focused brainstorming
Identify the one design question that affects the result. Read relevant existing context once. Ask only for missing product preferences that cannot be inferred. Offer at most two approaches when a real tradeoff exists, then recommend one. For a clear, already-authorized change, proceed without a brainstorming interview. A formal spec, separate approval checkpoint, prototype, or parallel design exercise is required only when requested or justified by the task's actual risk. Do not automatically create commits, PRs, diagrams, or a second planning workflow.
