---
name: test-driven-development
description: "Use when TDD is requested or a cheap regression test protects a meaningful behavior change."
disable-model-invocation: true
---

Local low-token policy: follow ~/.codex/AGENTS.md. Use one workflow, no automatic panels, and low reasoning only. Model defaults below are subordinate to that policy.

# Behavior-focused TDD
Use a failing test first when requested or when a cheap regression test prevents a meaningful bug from returning. Observe the relevant failure, implement the smallest fix, and confirm the test passes. Assert behavior through the public interface, not implementation details. For prose, configuration, assets, or trivial reversible edits, use direct validation instead. Do not add redundant tests or force a test harness onto a task that has none. Respect explicit project testing requirements. Run affected checks once; repeat after changes or actual failures.
